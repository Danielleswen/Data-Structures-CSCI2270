#include "BookCollection.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

BookCollection::BookCollection() {
    //TODO
    root=nullptr;
}

BookCollection::~BookCollection() {
    //TODO
    if (root==nullptr)
    {
        return;
    }
    else
    {
        _destruct(root);
    }
}

void BookCollection::_destruct(Book* currNode)
{
    if(currNode!=nullptr)
    {
        _destruct(currNode->left);
        _destruct(currNode->right);
        delete currNode;
    }
}

void BookCollection::removeBook(string bookName) {
    //TODO
   _removeBook(root, bookName);


}

void BookCollection:: _removeBook(Book* &currnode, string bookName)//void
{
    if (bookName=="")
    {
        return;
    }

   if (currnode==nullptr|| search(currnode, bookName)==nullptr)
    {
        cout << "Book not found!" << endl;
    }
    
    else if (bookName < currnode->bookName)
    {
        _removeBook(currnode-> left, bookName);
    }

     else if ( bookName > currnode->bookName)
    {
        _removeBook(currnode ->right, bookName);
    }
       
    else 
    {
            if ((currnode->left ==nullptr)&& (currnode->right ==nullptr))
            {
                delete currnode;
                currnode=nullptr;
            }
            else if((currnode->left ==nullptr)&& (currnode->right !=nullptr))
            {
                Book* newNode= currnode->right;
                delete currnode;
                currnode= newNode;
            }
            else if ((currnode->left!=nullptr)&& (currnode->right== nullptr))
            {
                Book* newNode = currnode->left;
                delete currnode;
                currnode=newNode;
            }
            else
            {
                Book* match= _searchMinHelper(currnode->right);
                currnode->bookName= match->bookName;
                currnode->author=match->author;
                currnode->rating=match->rating;
                _removeBook(currnode->right, currnode->bookName);
            }
        

    }
}


Book* BookCollection::search(Book*& node, string bookName)//good
{
    if (node == nullptr) {
		return node;
	}

	else if (bookName==node->bookName) {
		return node;
	} 

	else if (bookName < node->bookName)
    {
        return search(node->left, bookName);
    }

    else
    {
        return search(node->right, bookName);
    }

}

Book* BookCollection::_searchMinHelper(Book*& T) {
    if (T == nullptr) return nullptr;
    else if (T->left == nullptr) return T;
    else return _searchMinHelper(T->left);
}

void BookCollection::rotateLeftCollection(string bookName)
{
    Book* currnode= search(root, bookName);

    if (currnode==nullptr)
    {
        return;
    }
    else
    {
        _rotateLeftCollection(currnode);
    }
}

Book* BookCollection::_searchParent(Book*& currnode, Book* baby) {

    if (currnode==nullptr || currnode->right==baby || currnode->left==baby)
    {
        return currnode;
    }

    return _searchParent(currnode->left, baby);
    return _searchParent(currnode->right, baby);
  
}


void BookCollection::_rotateLeftCollection(Book* currnode) {
    //TODO
    
        Book* x =currnode;
        Book* y= x->right;

		if (x==nullptr||x->right==nullptr)
        {
            return;
        }

        if (x==root)
        {
            x->right=y->left;
            y->left=x;
            root=y;
        }
        else
        {
            x->right=y->left;
            y->left=x;

            Book* xp = _searchParent(root, x);

            if (xp->left==x)
            {
                xp->left=y;
            }
            else if (xp->right==x)
            {
                xp->right=y;
            }

        }

	return;
}



string BookCollection::closestParent(string book1, string book2) {
    //TODO
    string parentBook = "";
    if (search(root,book1)==nullptr||search(root, book2)==nullptr)
    {
        parentBook= "Error - wrong book name";
        cout << "Book not found!" << endl;
    }

    else
    {
        string book1a[100];
        string book2a[100];

        book1a[0]=root->bookName;
        book2a[0]=root->bookName;

        Book* currnode=root;

        int counta=1;
        int countb=1;
        //cout << book1 << book2 << endl;

        while(currnode->bookName!=book1)
        {
            if(book1<currnode->bookName)
            {
                book1a[counta]=currnode->bookName;
                //cout << book1a[counta] << endl;
                counta++;
                currnode=currnode->left;
            }
            else if(book1>currnode->bookName)
            {
                book1a[counta]=currnode->bookName;
                //cout << book1a[counta] << endl;
                counta++;
                currnode=currnode->right;
            }
        }
        book1a[counta]=book1;
        //cout << book1a[counta] << endl;

        currnode=root;
        while(currnode->bookName!=book2)
        {
            if(book2<currnode->bookName)
            {
                book2a[countb]=currnode->bookName;
                //cout << book2a[countb] << endl;
                countb++;
                currnode=currnode->left;
            }
            else if(book2>currnode->bookName)
            {
                book2a[countb]=currnode->bookName;
                //cout << book2a[countb] << endl;
                countb++;
                currnode=currnode->right;
            }
        }
        book2a[countb]=book2;
       // cout << book2a[countb] << endl;


        for (int i=0; i< counta+1; i++)
        {
            for (int j=0; j< countb+1; j++)
            {
                if (book1a[i]==book2a[j])
                {
                    parentBook=book2a[j];
                }
            }
        }
    }
    return parentBook;
}
