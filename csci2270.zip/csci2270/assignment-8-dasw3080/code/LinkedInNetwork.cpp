#include "LinkedInNetwork.hpp"
#include <vector>
#include <queue>
#include <iostream>

using namespace std;

void LinkedInNetwork::addProfessional(string name){
    //TODO
    bool found= false;

    for (int i=0; i < professionals.size(); i++)
    {
        if (professionals[i]->name== name)
        {
            found = true;
            cout << name << " found." << endl;
        }
    }

    if (found==false)
    {
        Professional* tmp= new Professional;
        tmp-> name = name;
        tmp -> connectionOrder=0;
        professionals.push_back(tmp);
    }

}

void LinkedInNetwork::addConnection(string v1, string v2){
    //TODO
    
    for (int i=0; i<professionals.size(); i++)
    {
        if (professionals[i]->name==v1)
        {
            for (int j=0; j< professionals.size(); j++)
            {
                if (professionals[j]->name== v2 && i!=j)
                {
                    neighbor ne;
                    ne.v=professionals[j];
                    professionals[i]->neighbors.push_back(ne);

                    neighbor ne2;
                    ne2.v=professionals[i];
                    professionals[j]->neighbors.push_back(ne2);
                }
            }
        }
    }
}

void LinkedInNetwork::displayConnections(){
    //TODO
    for(vector<Professional*>::iterator itr = professionals.begin(); itr != professionals.end(); itr++)
	{
		cout << (*itr)->name << " --> ";
		
		for(int j=0; j < (*itr)->neighbors.size(); j++)
		{
			cout << (*itr)->neighbors[j].v->name << " ";
		}
		cout << endl;
	}
}

void LinkedInNetwork::breadthFirstTraverse(string sourceProfessional){
    //TODO
    // for the source vertex in the network
cout << "Starting Professional (root): " << sourceProfessional << "-> ";

 Professional *vStart;

    for(int i = 0; i < professionals.size(); i++)
    {
        if(professionals[i]->name == sourceProfessional)
        {
            vStart = professionals[i];
        }
    }

    vStart->visited = true;

    // Use the queue to keep track of visited vertices
    queue<Professional*> q;

    // Enqueue the source vertex
    q.push(vStart);

    Professional *n;

    // standard BFS
    while(!q.empty()){

        n = q.front();
        q.pop();

        // go to all the adjacent vertices of n
        for( int x = 0; x < n->neighbors.size(); x++ )
        {
            // If a adjacent has not been visited, then mark it visited and enqueue it
            // Update the distance of the adjacent vertices along the way
            // Stop when you reach the destination vertex and return the needful

            if (n->neighbors[x].v->visited==false)
            {   


                n->neighbors[x].v->visited=true;
                q.push(n->neighbors[x].v);
                n->neighbors[x].v->connectionOrder=n->connectionOrder+1;
                cout << n->neighbors[x].v->name <<"("<< n->neighbors[x].v->connectionOrder <<")"<< " ";


            }
        }

    }
    

}

void bfs_helper(string source, vector<Professional*> &professionals) {

Professional *vStart;

    for(int i = 0; i < professionals.size(); i++)
    {
        if(professionals[i]->name == source)
        {
            vStart = professionals[i];
        }
    }

    vStart->visited = true;

    // Use the queue to keep track of visited vertices
    queue<Professional*> q;

    // Enqueue the source vertex
    q.push(vStart);

    Professional *n;

    // standard BFS
    while(!q.empty()){

        n = q.front();
        q.pop();

        // go to all the adjacent vertices of n
        for( int x = 0; x < n->neighbors.size(); x++ )
        {
            // If a adjacent has not been visited, then mark it visited and enqueue it
            // Update the distance of the adjacent vertices along the way
            // Stop when you reach the destination vertex and return the needful

            if (n->neighbors[x].v->visited==false)
            {   

                n->neighbors[x].v->visited=true;
                q.push(n->neighbors[x].v);
                n->neighbors[x].v->connectionOrder=n->connectionOrder+1;

            }
        }

    }


}


vector<string> LinkedInNetwork::suggestProfessionalsWithinKthOrder(string professionalName, int k){
    vector<string> professionalsWithinK;

    bfs_helper(professionalName, professionals);

    for (int i=0; i < professionals.size(); i++)
    {
        if (professionals[i]->connectionOrder<=k && professionals[i]->connectionOrder!=0)
        {
            professionalsWithinK.push_back(professionals[i]->name);
        }
    }

    return professionalsWithinK;
    
}