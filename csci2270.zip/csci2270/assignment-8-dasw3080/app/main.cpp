#include <iostream>
#include <vector>
#include "../code/LinkedInNetwork.hpp"
#include <string>
using namespace std;

int main(int argc, char** argv)
{
    return 0;
}
