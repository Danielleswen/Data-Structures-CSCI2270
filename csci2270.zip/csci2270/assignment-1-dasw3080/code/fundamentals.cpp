#include "fundamentals.hpp"
#include <fstream>
#include <iostream>

void insertStockInfo(stockInfo stocks[], string company_name, double stock_prices_arr[], int index) {
    // TODO
    
    stockInfo new_stock;//make a new stock object
    new_stock.company_name=company_name;//set the company name to the new object

    for (int i=0; i <5; i++)//duplicate the stocks for the new stock object
    {
        new_stock.stock_prices_arr[i]=stock_prices_arr[i];
    }

    double average=0.0;//create an average value, initially at 0

    for(int i=0; i<5; i++)// loop through each value and add to compute average
    {
        average=average+stock_prices_arr[i];
    }

    new_stock.average=average/5;// set the average value of the new object to the sum of each stock divided by 5

   stocks[index]=new_stock;//add the new stock to the stock index

    return;
}

void displaySortedStocks(stockInfo stock, ofstream& file){
    // TODO
   
    double holder[5]={0,0,0,0,0};//initialize a holder array to sort the stocks
    
    for (int i=0; i<5; i++)// go through each of the stock prices in the array of stock prices for an object
    {
        int index=0;//set the index for the holder array

        while(stock.stock_prices_arr[i]>holder[index]&&holder[index]!=0)// begin to compare values, if the value is bigger than the value at the inde, and the index isnt 0, move to the next position
       {
            index++;//increment position
       }

       if (holder[index]==0)//if the value at index is 0, that means it is unused
       {
            holder[index]=stock.stock_prices_arr[i];//so the value can be added in that position
       }
    
       else if(stock.stock_prices_arr[i]<holder[index])// if the value is smaller than the one in the holder, it will move all of the values in the holder down and put that one in that index
       {
            for (int i=3; i>=index; i--)
            {
                holder[i+1]=holder[i];
            }
            
            holder[index]=stock.stock_prices_arr[i];
       }
    
    }

    for (int i=0; i <5; i++)//update the array with the correct ascending values
    {
        stock.stock_prices_arr[i]=holder[i];
    }

    cout << stock.company_name << "," << stock.average << ",";//display the name , average, and the 5 ordered values
    for (int i=0; i<4; i++)
    {
        cout << stock.stock_prices_arr[i] << ",";
    }
    cout << stock.stock_prices_arr[4] << endl;//display the last value without a comma after it


    file << stock.company_name << "," << stock.average << ",";//write to the output file the name, average, and 5 ordered values
    for (int i=0; i<4; i++)
    {
        file <<stock.stock_prices_arr[i] << ",";
    }
    file <<stock.stock_prices_arr[4] << endl;//display the last value without a comma after it

    return;
}
