#include <iostream>
#include <fstream>
#include "../code/fundamentals.hpp"
#include <sstream>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
    // TODO

    if (argc<3)//user has to have the correct number of files
    {
        cout << "invalid file name" << endl;
    }

    string filename=argv[1];//set the filename by the first argv argument after the normal file name


    string line;//line for ifstream to read
    stockInfo stocks[4];//an array of type stockInfo to hold each of the companies
    int index=0;//beginning index of stocks array
    

    ifstream myFile;//create ifstream object
    myFile.open(filename);//open the filename the user inputted

    while(getline(myFile,line))//read one line at a time
    {
        stringstream ss(line);//stringstream object to split up line read from file
        string company_name;//company name for insertStockInfo()
        double stock_prices_arr[5];//array for insertStockInfo()
        string temp[6];//temporary array to hold items from read line
        string buf;//the object that will hold each section of the line and put it in the array
        int x=0;//counter for place in the temporary array

        while(getline(ss,buf,','))//to split up the line by commas
        {
            temp[x]=buf;//add the split up object into the temporary array
            x++;//increment through temporary array
        }

        company_name=temp[0];//set the company name

        for (int i=0; i<5;i++)//take the stock prices and store them in the stock prices array as a double float value
        {
            stock_prices_arr[i]=stod(temp[i+1]);// put the values in the array
        }

        insertStockInfo(stocks, company_name, stock_prices_arr, index);//run insertStockInfo to find average and store in struct array

        index++;//increment index for structs stocks array
    } 

    ofstream oFile;//create open file object
    oFile.open(argv[2]);//open the output file
    for (int i=0; i<index; i++)//loop through the stocks array and display each of the stocks
    {
    displaySortedStocks(stocks[i], oFile);//use display sorted stocks function to display and write to file
    }

    return 0;
}