//#pragma once sta
#endif ARRAY_LIST_HPP
#define ARRAY_LIST_HPP

using namespace std;

class ArrayList {

public: 
    ArrayList();
    ~ArrayList();

    void insertNode(string val, int idx);
    void deleteNode(int idx);
    
    void traverse();
    int search (string key);

    int get_size();


private: 
    string *head;
    int size;
    int capacity;
    int doubling;
    void resize();
};


#endif 