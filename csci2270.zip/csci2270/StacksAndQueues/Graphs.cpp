#include<iostream>
#include<vector>
#include<queue>
#include<stack>
 
#include "Graph.hpp"

using namespace std;

Graph::Graph() {
    // No bookkeeping required
}

Graph::~Graph() {
    // No bookkeeping required
    // for (int i=0; i< nodes.size(); i++)
    // {
    //     delete nodes[i];
    // }
    for (auto node : nodes)
    {
        delete node;
    }
}

void Graph::addNode(string _name) {
    GraphNode* tmp= getNode(_name);

    if (tmp!=nullptr)
    {
        cout << "Node already exists" << endl;
    }

    else{
        tmp= new GraphNode(_name);
        nodes.push_back(tmp);
    }

}

void Graph::addEdge(string _u, string _v) {
    GraphNode* u = getNode(_u);
    GraphNode* v = getNode(_v);

    if (u==nullptr || v==nullptr)
    {
        cout << "nuodes do not exist" << endl;
    }
    else
    {
        for (int i= 0; i < u->adjList.size(); i++)
        {
            if(u->adjList[i].end == v)
            {
                return;
            }
        }
        GraphEdge e(v);
        u->adjList.push_back(e);


    }
}

void Graph::print() {
    for (int i=0; i <nodes.size(); i++)
    {
        if (nodes[i]->visited) cout << "{" << nodes[i]->name << "*)";
        else cout << "{" << nodes[i]->name << ")";

        for (int j=0; j <nodes[i]->adjList.size(); j++)
        {
            cout << "->" << nodes[i]->adjList[j] << endl;
        }
        //cout << endl;
    }
}

void Graph::depthFirstTraversal(string _src) {
GraphNode* src= getNode(_src);

if ( src==nullptr)
{
    cout << "Node " << _src << " does not exist" << endl;
    return;
}
else
{
    eraseMarks();
    src->visited=true;
    _depthFirstTraversal(src);
}


}

void Graph::_depthFirstTraversal(GraphNode* s) {
// for (int i=0; i < s->adjList.size(); i++)
// {
//     if (s->adjList[i].end->visited == false)
//     {
//         _depthFirstTraversal(s->adjList[i].end);
//     }
// }

s->visited= true;
for (auto edge : s-> adjList)
{
    if (edge.end->visited)
    {
        _depthFirstTraversal(edge.end);
    }
}

}

void Graph::breadthFirstTraversal(string _src) {
    GraphNode* src=getNode(_src);
    if (src)
    {
        queue<GraphNode*> qq;
        src->visited = true;
        qq.push(src);
        while (!qq.empty())
        {
            GraphNode* u = qq.front();
            qq.pop();
            for (auto edge: u-> adjList)
            {
                if(!edge.end->visited)
                {
                    edge.end->visited = true;
                    qq.push(edge.end);
                }

            }
        }
    }
}

bool Graph::dfs(string _src, string _dst) {
    return false;
}

bool Graph::bfs(string _src, string _dst) {
    return false;
}

GraphNode* Graph::getNode(string _u) {
    // for (int i =0; i< nodes.size(); i++)
    // {
    //     if (nodes[i]->name==_u)
    //     {
    //         return nodes[i];
    //     }
    // }
    // return nullptr;


    for (auto node : nodes)
    {
        if (node->name== _u)
        {
            return node;
        }
    }

    return nullptr;
}

bool Graph::isEdge(string _u, string _v) {
    return false;
}

void Graph::eraseMarks() {
//  for (int i =0; i< nodes.size(); i++)
//     {
//         nodes[i]->visited=false;
//     }
//     for (int i =0; i< nodes.size(); i++)
//     {
//         nodes[i]->distance=-1;
//     }
    
    for (auto node: nodes)
    {
        node->visited=  false;
        node ->distance= -1;
    }
}

void Graph::DijsktraAlgorithm(string _src, string _dst) {

}