Node* BST::magicA(Node* currNode, int* counter, int k)
2. {
3. if ( currNode == NULL) {
4. return NULL;
5. }
6.
7. Node* right = magicA(currNode->rightChild, counter, k);
8. if (right != NULL) {
9. return right;
10. }
11.
12. ++(*counter);
13.
14. if (*counter == k) {
15. return currNode;
16. }
17.
18. return magicA(currNode->leftChild, counter, k);
19. }
20.
21.
22. Node* BST::magicB(Node* currNode, int* counter, int l)
23. {
24.
25. if ( currNode == NULL) {
26. return NULL;
27. }
28.
29. Node* left = magicB(currNode->leftChild, counter, l);
30.
31. if (left != NULL) {
32. return left;
33. }
34.
35. ++(*counter);
36.
37. if (*counter == l) {
38. return currNode;
39. }
40.
41. return magicB(currNode->rightChild, counter, l);
42. }
43. int BST::getDifference(int k, int l) {
44. int counter = 0;
45.
46. Node* node1 = magicA(root, &counter, k);
47.
48. counter = 0;
49.
50. Node* node2 = magicB(root, &counter, l);
51.
52. return node1->key - node2->key;
53. }