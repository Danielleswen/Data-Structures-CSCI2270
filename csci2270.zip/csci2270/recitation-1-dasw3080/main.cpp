#include "addEmployee.hpp"
using namespace std;

int split(string input_string, char separator, string arr[], int arr_size)
{
    string curString="";
    int num_of_splits=0;

    if (input_string=="")// if there's no string
    {
        return 0;// return 0
    }   

    for (int i=0; i<input_string.length(); i++)
    {

        if(/*(=isalnum(input_string[i]) || isspace(input_string[i])) && */ input_string[i] != separator)
        {
            curString= curString + input_string[i];
        }

        if(input_string[i]== separator)
        {
            arr[num_of_splits]={curString};
            //array[size+1]=input_string.substr(i+1);
            //size+=2;
            curString="";
            num_of_splits+=1;
        }
    }
arr[num_of_splits]=curString;

if (num_of_splits>arr_size)// if the number of times seperated is greater than the array, return -1
{
    return -1;
}
if (num_of_splits==0)// if the string was never seperated, put the whole string in position 0 in array and return 1
{
    arr[0]=input_string;
    return 1;
}

return num_of_splits;
}

int main(int argc, char *argv[])//argc[1]
{
    // check for number of arguments
    if (argc < 2)
    {
        cout << "file name missing" << endl;
        return -1;
    }

    string fileName = argv[1]; // TODO 1: get the file name from the command line parameters

    employee array[4];

    // open the file
    ifstream myfile;
    myfile.open(fileName);

    string line;
    string name;
    string emailid;
    string birthday;
    string holder[3];
    int count=0;

    if (myfile.is_open()) // check that this file exists
    {
        // TODO 2:  Read each line from the file
        //          for each line do the following
        //               extract name, extract email, extract birthday
        //               call the addAemployee function to add them in the array
        while (getline(myfile, line))
        {
            split(line, ',', holder, 3);
            count=addAnEmployee(array, holder[0], holder[2], holder[1], count);
        }

    }
    else
    {
        cout << "err: can not open file" << endl;
    }

    for (int i = 0; i < 4; i++)
    {
        cout << "name:" << array[i].name << " email:" << array[i].email << " bday:" << array[i].birthday << endl;
    }

    return 0;
}