#include "BookCollection.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

BookCollection::BookCollection() {
    //TODO
  root=nullptr;

}

BookCollection::~BookCollection() {
    //TODO
    if (root==nullptr)
    {
        return;
    }
    else
    {
        destruct(root);
    }
}


void BookCollection::destruct(Book* currNode)
{
    if(currNode!=nullptr)
    {
        destruct(currNode->left);
        destruct(currNode->right);
        delete currNode;
        currNode=nullptr;
    }
}

void BookCollection::addBook(string bookName, string author, double rating) {
    //TODO

    root=_addBook(root, bookName, author, rating);

}

Book* BookCollection::_addBook(Book* currNode, string bookName, string author, double rating)
{
    if (currNode==nullptr)
    {
        Book* tmp= new Book(bookName, author, rating);
        return tmp;
    }  
    else if (currNode->bookName < bookName)
    {
        currNode->right=_addBook(currNode->right, bookName, author, rating);
    }

    else  
    {
        currNode->left=_addBook(currNode->left, bookName, author, rating);
    }
    
    return currNode;
   

}

void BookCollection::showBookCollection() {
    //TODO
    if (root==nullptr)
    {
        cout << "Collection is empty." << endl;
    }
    else
    {
        _showBookCollection(root);
    }
}

void BookCollection::_showBookCollection(Book* currNode)
{
    if(currNode)
    {
        _showBookCollection(currNode->left);
        cout << "BOOK: " << currNode->bookName << " BY: " << currNode->author << " RATING: " << currNode->rating << endl;
        _showBookCollection(currNode->right);

    }
}

void BookCollection::showBook(string bookName) {
    //TODO

    if (root==nullptr)
    {
        cout << "Book not found." << endl;
        return;
    }

    
    Book* outcome = _showBook(root, bookName);
    
    if (outcome==nullptr)
    {
        cout << "Book not found." << endl;
    }

}

Book* BookCollection::_showBook(Book* currNode, string bookName)
{

    if(currNode)
    {   
        if(currNode->bookName==bookName)
        {

            cout << "Book:" << endl;
            cout << "==================" << endl;
            cout << "Name :" << currNode->bookName << endl;
            cout << "Author :" << currNode->author << endl;
            cout << "Rating :" << currNode->rating << endl;
            return currNode;
        }
        if (currNode->bookName > bookName)
        {
            return _showBook(currNode->left, bookName);
        }
        if(currNode->bookName< bookName)
        {
           return _showBook(currNode->right, bookName);
        }
    }
    else
    {
        return nullptr;
    }


}

void BookCollection::showBooksByAuthor(string author) {
    //TODO
    cout << "Books By: " << author << endl;
    _showBooksByAuthor(root, author);

}

void BookCollection::_showBooksByAuthor(Book* currNode, string author)
{
    if(currNode)
    {   
        _showBooksByAuthor(currNode->left, author);
        if(currNode->author==author)
        {
            cout << currNode->bookName << " RATING: " << currNode->rating << endl;
        }
        _showBooksByAuthor(currNode->right, author);
    }
}


void BookCollection::showHighestRatedBooks() {
    //TODO
    double highest=0;
    if (root==nullptr)
    {
        cout << "Collection is empty." << endl;
    }
    else
    {
        _showHighestRatedBooks(root, highest);
        cout << "Highest Rating: " << highest << endl;
        _showHighestRatedBooks1(root, highest);
    }
    

}

void BookCollection::_showHighestRatedBooks(Book* currNode, double & highest)
{
    
    if(currNode)
    {   
        _showHighestRatedBooks(currNode->left, highest);
        if(currNode->rating>highest)
        {
            highest=currNode->rating;
        }
        _showHighestRatedBooks(currNode->right, highest);

    }

}

void BookCollection::_showHighestRatedBooks1(Book* currNode, double highest)
{
    if(currNode)
    {
        _showHighestRatedBooks1(currNode->left, highest);

        if(currNode->rating==highest)
        {
            cout << currNode->bookName << " BY: " << currNode->author << endl;
        }

        _showHighestRatedBooks1(currNode->right, highest);
    }
}

int BookCollection::getHeightOfBookCollection() {
    //TODO
    if (root==nullptr)
    {
        return 0;
    }
    else
    {
        return _getHeightOfBookCollection(root);
        
    }
}

int BookCollection::_getHeightOfBookCollection(Book* currNode)
{
    if (currNode)
    {
        int num=0;
        num= _getHeightOfBookCollection(currNode->left);
        int num1=0;
        num1= _getHeightOfBookCollection(currNode->right);

        if (num>num1)
        {
            return num+1;
        }
        else
        {
            return num1+1;
        }
    }
    return 0;

}
