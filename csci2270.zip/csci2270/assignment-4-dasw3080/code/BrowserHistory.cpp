
#include "BrowserHistory.hpp"

BrowserHistory::BrowserHistory()
{
    // No changes needed
}

BrowserHistory::~BrowserHistory()
{
    // No changes needed
}

/*
 * Purpose: Has to detect if a defect is present in the linkedlist pointed by head
 * @param none
 * @return integer length of defect if one exists. If defect not present return -1
 */
int BrowserHistory::findDefectLength(){

    // TODO START =============================================

    WebPage* fast= new WebPage;
    WebPage* slow= new WebPage;
    
    fast=head;
    slow=head;

    int counter=0;


    while(fast!=nullptr)
    {
        fast=fast->next;
        slow=slow->next;

        if (fast==nullptr)
        {
            return -1;
        }
        else 
        {
            fast=fast->next;
        }

        if(fast==slow)
        {
            slow=slow->next;
            counter++;

            while(slow!=fast)
            {
                counter++;
                slow=slow->next;

            }

            return counter;
        }
        
    }
    
    return -1;
    // TODO END ==================================================
}

/*
 * Purpose: Has to remove all the WebPage nodes from [start, end] inclusive.
 * Has to print appropriate messages on cout like below if the linkedlist is empty
 * or if the values of start/ end are improper
 * follow the same order for couts in the writeup - check empty list first, then check wrong start/end values
 * @param integers start and end (1 based indexing not 0 based)
 * @return none
 */
void BrowserHistory::removeWebPages(int start, int end){

    // TODO START ===================================================

    if (head==nullptr)
    {
        cout << "Browsing history is Empty" << endl;
        return;
    }

    int length=1;

    WebPage* trav= new WebPage;
    trav=head;

    while(trav!=nullptr)
    {
        trav=trav->next;
        length++;
    }

    if (start<1||start>end||end>length)
    {
        cout << "Invalid start or end values" << endl;
        return;
    }

    WebPage* start_ptr= new WebPage;
    WebPage* end_ptr= new WebPage;
    WebPage* b4_start = new WebPage;
    WebPage* aft_end = new WebPage;

    int pos=1;
    trav=head;
    while(trav!=nullptr)
    {

        if(pos==(start-1))
        {
            b4_start=trav;
            start_ptr=trav->next;
        }

        if(pos==end)
        {
            aft_end=trav->next;
            end_ptr=trav;
        }
        
        trav=trav->next;
        pos++;
    }



    if (start==1)
    {
        if (end==length)
        {
            head=nullptr;
            return;
        }

        head=end_ptr->next;
        return;
    }

    else if(start==end)
    {
        b4_start->next=start_ptr->next;
    }

    else
    {
        b4_start->next=aft_end;
        return;
    }   
    // TODO END ===================================================
}


/*
 * Purpose: Interweave the webpages alternatively into a new linkedlist 
 * starting with the first webpage in the list one
 * Assign the head of the new interweaved list to the head of this BrowserHistory
 * DO NOT create new nodes and copy the data, just use the same nodes from one and two and change pointers
 * If one of them runs out of length append the remaining of the other one at end
 * @param two linkedlist heads one and two
 * @return none
 */
void BrowserHistory::mergeTwoHistories(WebPage *headOne, WebPage * headTwo){

    // TODO START =============================================

if (headOne==nullptr&&headTwo==nullptr)
{
    head=headOne;
    return;
}

if(headOne==nullptr)
{
    head=headTwo;
    return;
}

if (headTwo==nullptr)
{
    head=headOne;
    return;
}

head=headOne;
WebPage* holder1= new WebPage;
WebPage* holder2= new WebPage;

holder1=headOne;
holder2=headTwo;

while(headOne!=nullptr)
{
    if(headTwo==nullptr)
    {
        return;
    }

    holder1 = headOne->next;
    headOne->next=holder2;

    holder2 = headTwo->next;
    headTwo->next=holder1;
    
    headOne=holder1;
    headTwo= holder2;
}

    if(headTwo!=nullptr)
    {
        headOne=headTwo;
        return;
    }
    
    return;

    delete holder1;
    delete holder2;

    // TODO END ==================================================
}
`