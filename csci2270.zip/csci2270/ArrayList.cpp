#include <iostream>
#include "ArrayLists.hpp"

using namespace std;

ArrayList::Arraylist(){
size=0;
capacity=10;
head = new string[capacity];
}

ArrayList::~ArrayList(){
    delete[] head;
}

void ArrayList::insertNode(string val, int idx){

    if((idx<0)|| (idx>size))
    {
        cout << "incorrect index." << endl;
        return;
    }
    
    if(size>=capactity)
    {
        resize();
    }

    for (int i=size; i>idx; i--)
    {
        head[i]=head[i-1];
    }
    head[idx]= val;


}

void ArrayList::deleteNode(int idx){

}
    
void ArrayList::traverse(){
cout << "[" << endl;
for (int i=0; i < size; i++)
{
    cout << head[i] << endl;
}

cout << "]" << endl;
}

int ArrayList::search (string key){

}

int ArrayList::get_size(){

}
    
void ArrayList::resize(){

string* newHead= new string[2*capacity];

for (int i=0; i<capacity; i++)
{
    neadHead[i]= head[i];
}

delete[] head;
head=newHead;

}