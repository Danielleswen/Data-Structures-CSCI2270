#ifndef TAX_HPP
#define TAX_HPP

#include <iostream>

using namespace std;

/*TODO 1: Create a struct "TaxInfo" with salary and tax rate.
* ...
*/

struct TaxInfo
{
    float salary;
    float tax_rate;
};



#endif