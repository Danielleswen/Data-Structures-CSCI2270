#include <iostream>
using namespace std;

void add3(int *a){
    a[0] +=3;
}

int some_num=19;

void change_pointer(int* ptr)
{
    ptr= &some_num;
}

int* foo(int x);

struct student{
    string name;
    string email;
    string birthday;
};



int main(int argc, char* argv[]){
    // int a[] = {1,2,3};
    // add3(&a[1]);
    // for (int i=0; i<3; i++)
    // {
    //     cout << a[i] << "," << endl;
    // }
// int a = 9;
// int *pa = &a;
// change_pointer(pa);
// cout << *pa << endl;

// if (argc ==2){
//     int* res = foo(atoi(argv[1]));
//     delete res;
//     res=0;
// }


// int a=5;
// int b=10;
// int *pa=&a;
// int *pb=&b;
// pb=pa;

// cout << *pa << endl;
// return 0;



// student s;
// s.email="email";
// student *myStudent= &s;

// cout << myStudent->email << endl;
// cout << s.email << endl;
// cout << (&s)->email << endl;
//cout << s->email << endl;

return 0;
}
int* foo(int x)
{
    int* res = new int[x];
    return res;
}