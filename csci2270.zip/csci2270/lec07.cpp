#include <iostream>
//i like the solarized dark theme light blue
//abyss looks like space
//mayuki mono dark/normal but better colors/ reversal is similar 

#include "ArrayList.hpp"



using namespace std;

int main(){

ArrayList ll;
ll.insertNode("dani", 0);
ll.traverse();

ll.insertNode("hello",0);
ll.traverse();


return 0;
}