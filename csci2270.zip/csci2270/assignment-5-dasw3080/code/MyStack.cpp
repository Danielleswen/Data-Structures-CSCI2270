#include <iostream>
#include <cstdlib>
#include <iostream>
#include "MyStack.hpp"

using namespace std;

MyStack::MyStack()
{
	head = NULL;
}

MyStack::~MyStack()
{
	//TODO
	

	while(!isEmpty())
	{
		pop();
	}
}

bool MyStack::isEmpty()
{
	//TODO
	if (head==nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
	
	return true;
}


void MyStack::push(int val)
{
	//TODO
	Node* new_n= new Node;
	new_n->val=val;

	new_n->next=head;
	head=new_n;
	return;

	delete new_n;
}

void MyStack::pop()
{   
	if (isEmpty()==false)
	{
		head=head->next;

	}
	else
	{
		cout << "Stack empty, cannot pop an item!" << endl;
	}
}

Node* MyStack::peek()
{
	//TODO
	if (isEmpty()==false)
	{
		return head;
	}
	else{
		cout << "Stack empty, cannot peek!" << endl;
		return nullptr;
	}
}
