#include <iostream>
#include <cstdlib>
#include "MessageDecoder.hpp"

using namespace std;
# define SIZE 50

MessageDecoder::MessageDecoder()
{
	my_queue = new MyQueue();
	my_stack = new MyStack();
}

MessageDecoder::~MessageDecoder()
{
    delete my_queue;
    delete my_stack;	
}

/*
    generate_operator_queue(string jumbled_str)

    Takes the jumbled string as the input parameter and stores all the allowed operators in my_queue
*/
void MessageDecoder::generate_operator_queue(std::string jumbled_str){
    //TODO
    int ss=0;
    ss=jumbled_str.size();


    for (int i =0; i< ss; i++)
    {
        if (jumbled_str[i]==43||jumbled_str[i]==42||jumbled_str[i]==45)
        {
            char val;
            if (jumbled_str[i]==43)
            {
                val=43;
            }
            if(jumbled_str[i]==42)
            {
                val=42;
            }
            if(jumbled_str[i]==45)
            {
                val=45;
            }
            my_queue->enqueue(val);
        }
    }
}

/*
    generate_postfix(string jumbled_str)

    Takes the jumbled string as the input parameter and computes a postfix expression using the populated my_queue
    returns a postfix expression
*/
string MessageDecoder::generate_postfix(std::string jumbled_str){
    //TODO
	string postfix = "";
    int ss=0;
    ss=jumbled_str.size();
    int count=0;


    for (int i =0; i< ss; i++)
    {
        if(count==2 && my_queue->isEmpty()==false && (jumbled_str[i]==43||jumbled_str[i]==42||jumbled_str[i]==45))
        {
            postfix=postfix=postfix+jumbled_str[i];
            count=0;
            my_queue->dequeue();
        }
        else if (jumbled_str[i]>=48&&jumbled_str[i]<=57)//jumbled_str[i]!=43&&jumbled_str[i]!=42&&jumbled_str[i]!=45&&
        {
            postfix=postfix+jumbled_str[i];
            count++;
        }

    }

    while(my_queue->isEmpty()==false)
    {
        postfix=postfix+my_queue->peek();
        my_queue->dequeue();
    }
    return postfix;
}

/* 
    evaluate_postfix(string postfix) 

    Takes the post fix string as an input parameter and evaluates the post fix string. 
    returns an integer after evaluating the postfix expression
*/

int MessageDecoder::evaluate_postfix(std::string postfix){
    //TODO
    MyStack *operation= new MyStack;
    int ss=0;
    ss=postfix.size();

    for (int i=0; i < ss; i++)
    {   
        Node *holder= new Node;
        Node *holder1= new Node;
        int val=0;

        if (postfix[i]>=48&&postfix[i]<=57)
        {
            char ch=postfix[i];
            operation->push((ch-'0'));

        }

        else if(postfix[i]==43)// +
        {
            holder=operation->peek();
            operation->pop();

            holder1=operation->peek();
            operation->pop();

            val=(holder->val) + (holder1->val);

            operation->push(val);
            //
        }

        else if(postfix[i]==42)//*
        {
            holder=operation->peek();
            operation->pop();

            holder1=operation->peek();
            operation->pop();

            val=(holder->val)*(holder1->val);

            operation->push(val);
           
        }

        else if(postfix[i]==45)//-
        {
            holder=operation->peek();
            operation->pop();

            holder1=operation->peek();
            operation->pop();

            val=(holder1->val)-(holder->val);

            operation->push(val);
        }
        delete holder;
        delete holder1;
    }

  return operation->peek()->val;
}

//For Testing purposes only!
MyQueue* MessageDecoder::getQueue(){
    return my_queue;
}

//For Testing purposes only!
MyStack* MessageDecoder::getStack(){
    return my_stack;
}