#include "MyQueue.hpp"

#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

MyQueue::MyQueue(){
    queueFront = -1;
	queueEnd = -1;
}

bool MyQueue::isEmpty(){
	//TODO
	if(counter==0)
	{
		return true;
	}
	else
	{
		return false;
	}
    return true;
}

bool MyQueue::isFull(){
	//TODO
	if (counter>=SIZE)
	{
		return true;
	}
	else 
	{
		return false;
	}
    return true;
}

void MyQueue::enqueue(char ch){
	//TODO
	if (isFull())
	{
		cout << "Queue full, cannot add!\n";
		return;
	}
	else if(queueFront==-1)
	{
		
		queueFront=0;
		queueEnd=0;
		queue[queueEnd]=ch;
		counter++;
	}
	else if (queueEnd==SIZE-1)
	{
		queue[0]=ch;
		queueEnd=0;
		counter++;
	}
	else
	{
		queueEnd++;
		queue[queueEnd]=ch;
		counter++;
	}
	
}


void MyQueue::dequeue(){
	//TODO
	if (isEmpty())
	{
		cout << "Queue empty, cannot dequeue!" << endl;
	}
	else if (queueFront==queueEnd)
	{
		queueFront=-1;
		queueEnd=-1;
		counter--;
	}
	else if (queueFront==SIZE-1)
	{
		queueFront=0;
		counter--;
	}
	else
	{
		queueFront=queueFront+1;
		counter--;
	}
	return;
}


char MyQueue::peek(){
	//TODO
	if(!isEmpty())
        return queue[queueFront];
    else
    {
        cout << "Queue empty, cannot peek!\n";
		return '\0';
    }
}

int MyQueue::queueSize(){
    //TODO
    return counter;
}
