#include<iostream>
#include <fstream>
#include<cmath>
#include<iomanip>
#include "../code/MessageDecoder.hpp"

using namespace std;


int main(int argc, char* argv[])
{
   if (argc < 2) {
        cout << "Usage: ./run_app <inputfilename>" << endl;
        return 0;
    } else {
        string line="";
        ifstream iFile;// create a file in-stream variable
        iFile.open(argv[1]);
        if(iFile.is_open())
        {
        while(getline(iFile, line))
        {
          string jumbled_str=line;
          MessageDecoder instance;
          instance.generate_operator_queue(jumbled_str);
          string postfix=instance.generate_postfix(jumbled_str);
          int answer=instance.evaluate_postfix(postfix);
          cout << "Postfix Notation::" << postfix << endl;
          cout << "Final Answer::" << answer << endl;
        }
        }
        else{
          cout << "Error: Could not open file.\n";
        }

        return 0;
    }
    
  return 0;
}