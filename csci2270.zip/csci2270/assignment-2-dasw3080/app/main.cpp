#include <iostream>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "../code/array_double.hpp"

using namespace std;

int main(int argc, char* argv[])
{
    // TODO

    if (argc!=6)// if the correct number of arguments is not entered
    {
        cout << "Usage: ./run_app <inputfilename> <Query_Location> <Query_Variant> <Query_Start_Age> <Query_End_Age>" << endl;
    }

    else
    {
        ifstream iFile;// create a file in-stream variable
        iFile.open(argv[1]);//open the file given in the arguments

        int array_size=10;//make an initial array size of ten

        CovidCase*pa = new CovidCase[array_size];//making a new array of type CovidCase

        string queryP[4]={argv[2]/*location*/, argv[3]/*variant*/, argv[4]/*lower limit*/, argv[5]/*upper limit*/};//making an array to hold the query parameters

        int index=0;//variable for the CovidCase array

        int  double_count=0;//counter for how many times the array needs to be doubled

        parseFile(iFile, queryP, *&pa, array_size, index, double_count);
            /*
            this function holds isCaseQuiered, resizearray,addcase, and sortarray functions inside of it
            */
    
        iFile.close();//closing the file

    }
    return 0;
}