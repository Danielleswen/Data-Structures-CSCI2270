#include "array_double.hpp"
#include <sstream>

void parseFile(ifstream& input,string queryParams[], CovidCase *&cases, int &arrCapacity,  int &recordIdx, int &doublingCounter){
    // TODO
        string line="";

        while (getline(input, line))// go through the whole file and read each case
        {
                stringstream ss(line);//stringstream object to split up line read from file
                string temp[4];//temporary array to hold items from read line
                string buf="";//the object that will hold each section of the line and put it in the array
                int x=0;//counter for place in the temporary array

            while(getline(ss,buf,','))//to split up the line by commas
            {
                temp[x]=buf;//add the split up object into the temporary array
                x++;//increment through temporary array
            }

                CovidCase add_to_array;//make a new covid case object 
                add_to_array.name=temp[0];//take the 1st object in the temp array and set the name of the new covid case
                add_to_array.variant=temp[1];//take the 2nd object in the temp array and set the variant of the new covid case
                add_to_array.location=temp[2];//take the 3rd object in the temp array and set the location of the new covid case
                add_to_array.age=stoi(temp[3]);//take the 4th object in the temp array and set the age of the new covid case

            if (isCaseQueried(add_to_array, queryParams[0], queryParams[1], stoi(queryParams[2]), stoi(queryParams[3]))==true)//3 requirements, same place, same variant, same age group
            {
                addCase(cases, add_to_array, arrCapacity, recordIdx, doublingCounter);//if it passes, add the case to the array
            }
    
        }

        sortCases(cases, recordIdx);// after all the cases have been added, sort the array by age
        cout << "Array doubled: " << doublingCounter << endl;//cout the amount of times the array was doubled
        cout << "Total number of cases returned after the query: " << recordIdx << endl; // cout the number of cases there are
        printQueriedCases(cases, recordIdx);//print all of the cases
}

bool isCaseQueried(CovidCase covidCase, string queryLocation, string queryVariant, int startAge, int endAge) {
    // TODO
    if((covidCase.location==queryLocation) && (covidCase.variant==queryVariant) && (covidCase.age>= startAge) && (covidCase.age<=endAge))//if the places match, the variants match, and the age is in the age group, 
    {
        return true;//return true
    }

    return false;//default return false
}

void resizeArr(CovidCase *&cases, int *arraySize) {
    // TODO
    CovidCase * new_array= new CovidCase[(*arraySize)*2];//create a new array to double the old array

        for (int i =0; i < *arraySize; i++)//go through and add the old cases to the new array
        {
            new_array[i]=cases[i];
        }
        cases=new_array;//set the old array equal to the new array
      
        *arraySize= (*arraySize)*2;//update the array size by multiplying the array size by 2
}

void addCase(CovidCase *&cases, CovidCase covidCase, int &arrCapacity, int &recordIdx, int &doublingCounter) {
    // TODO
    if (recordIdx==arrCapacity)// if the index in the array is outside the bounds of the array, double the size of the array
        {
            resizeArr(cases, &arrCapacity);
            doublingCounter++;//increment the doubling counter
        }

    cases[recordIdx]=covidCase;// add the covid case to the array at the index
    recordIdx++;//increment the index by one
}

void sortCases(CovidCase* cases, int length) {
    // TODO
    for (int i=0; i< length-1; i++)// go through each number in the array
    {
        for (int j=0; j< length - i - 1; j++)//manages bubble sort technique by looping through the array and as the highest position gets set it will stop going to those values to sort
        {
            CovidCase holder;//make a holder case to swap

            if (cases[j].age>cases[j+1].age)// if the age at position j is greater than the next one, swap their positions
            {   
                holder=cases[j+1];
                cases[j+1]=cases[j];
                cases[j]=holder;  
  
            }
            else if (cases[j].age==cases[j+1].age)// if they equal the same age, compare their names and sort based off of whose name comes first in the alphabet
            {
                 
                int pos_in_names=0;// index in names
                while (cases[j].name[pos_in_names]==cases[j+1].name[pos_in_names])//while the letters in the peoples name are the same go to next position
                {
                    pos_in_names++;
                }
                if(cases[j+1].name[pos_in_names]<cases[j].name[pos_in_names])// if the next person has a name that should come first, swap the names
                {
                    holder=cases[j+1];
                    cases[j+1]=cases[j];
                    cases[j]=holder;
                }
            }
        }
    }

}

void printQueriedCases(CovidCase* cases, int numOfRecords) {
    // TODO
    cout << "Queried Cases\n---------------------------------------" << endl;

    for (int i=0; i<numOfRecords; i++)//go through and print the array of cases that match
    {
        cout << cases[i].name << " " << cases[i].age << endl;
    }
}