#include "worldMap.hpp"
#include <vector>
#include <stack>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

WorldMap::WorldMap() {}

void WorldMap::createWorldMap(string fileName)//row=y=i cols=x=j
{
    // TODO START
    string name= fileName;
    string line="";
    ifstream myFile;
    myFile.open(name);
    vector<string> holder;

    while(getline(myFile, line))
    {
        //cout << line << endl;
        holder.push_back(line);
    }

    myFile.close();
   
    stringstream ss(holder[0]);
    string buf="";
    int count = 0;
    while(getline(ss,buf,' '))
    {
        if (count==0)
        {
            rows=stoi(buf);
            count++;
        }
        else if (count==1)
        {
            cols=stoi(buf);
        }
    }

    holder.erase(holder.begin());

    worldMap= new int*[rows];
    for (int i=0; i <rows; i++)
    {
        worldMap[i]=new int[cols];
    }

    for (int i = 0; i < rows; i++)
    {   
        vector<int> number;
        stringstream ss1(holder[i]);
        string buf1;
        while(getline(ss1,buf1, ' '))
        {
            int new_num=stoi(buf1);
            number.push_back(new_num);
        }

        for( int j=0; j< cols; j++)
        {
            int aa= number[j]; 
            worldMap[i][j]=aa;
        }  
    }   

    // TODO END
}



void WorldMap::printWorldMap()
{
    // TODO START
    for (int i = 0; i< rows; i++)
    {
        cout << "|";

        for (int j=0; j < cols; j++)
        {
            cout << " " << worldMap[i][j] << " |";
        }
        cout << "" << endl;
    }

    // TODO END
}

void WorldMap::addRegion(int x, int y)
{
    // TODO START
    bool huh=false;
    for (unsigned int i=0; i<regions.size(); i++)
    {
        if(regions[i]->x==x && regions[i]->y==y)
        {
            huh=true;
        }
    }
    if (huh==false)
    {
        Region* newR= new Region;
        newR->x=x;
        newR->y=y;

        regions.push_back(newR);
    }

    // TODO END
}

bool checkIfEdgeExists(Region *r, int x2, int y2)
{
    for (unsigned int i = 0; i< r->neighbors.size(); i++)
    {
        if(r-> neighbors[i].region ->x== x2 && r-> neighbors[i].region ->y== y2)
        {
            return true;
        }
    }

    return false;
}

void WorldMap::addEdgeBetweenRegions(int x1, int y1, int x2, int y2)
{
    // TODO START
    for(unsigned int i = 0; i < regions.size(); i++){
        if(regions[i]->x == x1 && regions[i]->y == y1){
            for(unsigned int j = 0; j < regions.size(); j++){
                if(i != j && regions[j]->x == x2 && regions[j]->y == y2){
                    if(!checkIfEdgeExists(regions[i], x2, y2)){
                        NeighboringRegion av;
                        av.region = regions[j];
                        regions[i]->neighbors.push_back(av);
                        // another vertex for edge in other direction
                        NeighboringRegion av2;
                        av2.region = regions[i];
                        regions[j]->neighbors.push_back(av2);
                    }
                }
            }
        }
    }

    // TODO END
}

vector<vector<int>> WorldMap::findAdjacentLandRegions(int x, int y)
{
    // TODO START
       // identify the open paths that are adjacent to the vertex at x, y
    // fill adjArr array with the numbers of the adjacent vertices
    bool huh=false;
    vector<vector<int>> neighbors; 
    for(int i = x-1; i <= x + 1; i++){
        if(i < 0 || i >= this->rows){
            continue;
        }
        for(int j = y-1; j <= y+1; j++){
            if(j < 0 || j >= this->cols){
                continue;
            }
            // if there is an open path at this adjacent position, add to adjArray
            if(!(i == x && j == y) && worldMap[i][j] == 1){
                for (unsigned int z =0; z< neighbors.size(); z++)
                {
                    if(neighbors[z][0]==x &&neighbors[z][1]==y)
                    {
                        huh = true;
                    }
                }
                if (huh==false)
                {
                    neighbors.push_back({i,j});
                }
            }
        }
    }
    return neighbors;    // TODO END
}

void WorldMap::convertWorldMapToAdjacencyListGraph()//*****
{
    // TODO START
    for (int i=0; i< rows; i++)
    {
        for (int j=0; j< cols; j++)
        {
            if(worldMap[i][j]==1)
            {
                addRegion(i,j);
            }
        }
    }

    for(int i=0; i< rows; i++)
    {
        for (int j=0; j< cols; j++)
        {
            if(worldMap[i][j]==1)
            {
                vector<vector<int>> l=findAdjacentLandRegions(i,j);

                for (unsigned int z = 0; z< l.size(); z++)
                {
                    
                    addEdgeBetweenRegions(i,j, l[z][0], l[z][1]);
                    
                }
            }
        }
    }
    // TODO END
}
// helper function to check if v2 is a neighbor of verter v1
bool isNeighbor(int x1, int y1, int x2, int y2, const vector<Region *> regions)
{
    Region* v1, * v2;

    for(unsigned int i = 0; i < regions.size(); i++)
  {
      if(regions[i]->x == x1 && regions[i]->y==y1)
      {
        v1 = regions[i];
      }

      if(regions[i]->x == x2 && regions[i]->y== y2)
      {
        v2 = regions[i];
      }
  }

  for (unsigned int i= 0; i < v1->neighbors.size(); i++)
  {
    if(v1->neighbors[i].region == v2)
    {
        return true;
    }
    
  }

    return false;
}

WorldMap::~WorldMap()
{
    // TODO START
    for(auto region : regions)
    {
        delete region;
    }
    // TODO END
}

void WorldMap::displayEdges()
{
    // TODO START
    for (unsigned int i=0; i< regions.size(); i++)
    {
        cout<<"("<<regions[i]->x<<','<<regions[i]->y<<")"<<" --> ";

        for (unsigned int j=0; j < regions[i]->neighbors.size(); j++)
        {
            cout<<"("<<regions[i]->neighbors[j].region->x<<','<<regions[i]->neighbors[j].region->y<<")"<<" ";
        }
        cout << "" << endl;
    }
    // TODO END
}

// HELPER FOR findNumOfIslands
void findNumOfIslandsHelper(Region *r)
{
    r->visited = true;

    for(unsigned int x = 0; x < r->neighbors.size(); x++ )
    {
        // TODO
        if (r->neighbors[x].region->visited == false)
        {
            findNumOfIslandsHelper(r->neighbors[x].region);
        }

    }
    return;
}

int WorldMap::findNumOfIslands()
{
    // TODO START
    int comp=0;
    for (unsigned int i=0; i< regions.size(); i++)
    {
        if (regions[i]->visited==false)
        {
            findNumOfIslandsHelper(regions[i]);
            comp++;
        }
    }
    return comp;
    // TODO END
}

vector<Region *> &WorldMap::getRegions()
{
    return regions;
}
