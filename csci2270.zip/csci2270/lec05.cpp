#include <iostream>
using namespace std;


// void change(int x){
//     x=100;
// }
// int main(){

// int x=42;

// change(x);
// cout << " x= " << x << endl;//42

// return 0;
// }


void by_value(int y)
{
    y=100;
}

void by_ptr(int *px)
{
    *px=100;
}

void by_ref(int &y)//y is another name for x
{
    y=100;
}

void arrayByValue(int A[])//array cannot be passed by value cause its a pointer
{
    for (int i=0; i< 10; i++)
    {
        A[i]=i*2;
    }
}

void arrayDouble(int *&old_array, int &cap)
{
    int * new_array= new int[2*cap];

    for (int i =0; i < cap; i++)
    {
        new_array[i]=old_array[i];
    }

    for (int i=cap; i<2*cap; i++)
    {
        new_array[i]= rand()%10;
    }
    old_array=new_array;
    cap=2*cap;
}
int main()
{
    int cap=10;

    int* B = new int[cap];//heap, dynamically does the same thing ^ size can change

    for (int i=0; i< cap; i++)
    {
        B[i]=i;
    }

    for (int i=0; i< cap; i++)
    {
        cout << B[i] << " ";
    }
    cout << endl;

    arrayDouble(B, cap);


    for (int i=0; i< cap; i++)
    {
        cout << B[i] << " ";
    }
    //int B[10]; statically declared, items change
    // int* B = new int[10];//heap, dynamically does the same thing ^ size can change

    // for (int i=0; i< 10; i++)
    // {
    //     B[i]=i;
    // }

    // for (int i=0; i< 10; i++)
    // {
    //     cout << B[i] << " ";
    // }
    // cout << endl;
    // arrayByValue(B);

    // for (int i=0; i< 10; i++)
    // {
    //     cout << B[i] << " ";
    // }


    // delete[] B;
    // B= nullptr;

    // B[0]=100; //seg fault

    // if (B!=nullptr)
    // {

    // }

    //int *B = new int[10];

    //int x=42;
    //by_value(x); 42
    //by_ptr(&x); 100
    //by_ref(x); //100

    //cout << "x= " << x << endl;
        
    return 0;
}




//copy array to new array and insert new stuff


//to do
//1. create an integer array A of size ten with random values
//2. call a function to double the size of this array, copy first ten elements
// initialize 10 new values with different values
//set old array to this new array
//4 print the new array inside the doubleArray function
//5. print the new array inside the main function