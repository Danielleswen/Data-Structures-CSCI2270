/*************************************************************/
/*                BrowserHistory Definition                  */
/*************************************************************/
/* TODO: Implement the member functions of BrowserHistory    */
/*     This class uses a linked-list of WebPage structs to   */
/*     represent the schedule of web pages                   */
/*************************************************************/

#include "browserHistory.hpp"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

/*
 * Purpose: Constructor for empty linked list
 * @param none
 * @return none
 */
BrowserHistory::BrowserHistory() {
    /*
    DO NOT MODIFY THIS
    This constructor is already complete. 
    */
    head = nullptr;
}

/*
 * Purpose: Check if list is empty
 * @return true if empty; else false
 */
bool BrowserHistory::isEmpty() {
    /* finished. do not touch. */
    return (head == NULL);
}

/*
 * Purpose: prints the current list of pages 
 * in the given format.
 * [ID::1]-(URL::url1) -> ... -> NULL
 * @param none
 * @return none
 */
void BrowserHistory::displayHistory() {
    // TODO
    cout << "== CURRENT BROWSER HISTORY ==" << endl;
    if(isEmpty()==false)//if the browser isnt empty
    {
        WebPage* tmp=head;//set pointer to the head, and run through the linked list and display the values of each object
        while(tmp!=nullptr)
        {
            cout << "[ID:: " << tmp->id << "]-(URL::" << tmp->url << ") -> ";
            tmp=tmp->next;
        }
    }
    if(isEmpty()==true)// if the list is empty, cout empty history
    {
        cout << "Empty History\n";
    }
    cout << "NULL\n" << "===" << "\n";

}

/*
 * Purpose: Add a new webpage to the browser history LL
 *   between the previous and the page that follows it in the list.
 * @param previousPage, the show that comes before the new page
 * @param newPage, the webpage to be added. 
 * @return none
 */
void BrowserHistory::addWebPage(WebPage* previousPage, WebPage* newPage) {
    // TODO
    if(previousPage==NULL)//if the previous page doesnt point to anything
    {
        newPage->next=head;//set the next of the new page to be the head and the head equals the new page
        head=newPage;
        cout << "adding: [" << newPage->id << "]-" << newPage->url << " (HEAD)\n"; 
    }
    else
    {
        newPage->next=previousPage->next;//set the next of the new page to be the next of the previous page
        previousPage->next=newPage;// and the next of the previous page to be the new page
        cout << "adding: " << "[" << newPage->id << "]-" << newPage->url << " (prev: " << "[" << previousPage->id << "])\n";
    }
    
}

/*
 * Purpose: populates the BrowserHistory with the predetermined pages
 * @param none
 * @return none
 */
void BrowserHistory::buildBrowserHistory() {
    // TODO

    /*create a new webpage pointer for each website and add them to the linked list*/
    WebPage* tmp=new WebPage;
    WebPage* tmp2=new WebPage;
    WebPage* tmp3=new WebPage;
    WebPage* tmp4=new WebPage;
    WebPage* adding=new WebPage;


    adding->id=10;
    adding->url="https://www.colorado.edu/";
    addWebPage(nullptr,adding);

    tmp->id=11;
    tmp->url="https://www.wikipedia.org/";
    addWebPage(adding, tmp);

    tmp2->id=12;
    tmp2->url="https://brilliant.org/";
    addWebPage(tmp, tmp2);

    tmp3->id=13;
    tmp3->url="https://www.khanacademy.org/";
    addWebPage(tmp2, tmp3);

    tmp4->id=14;
    tmp4->url="https://www.numberphile.com/";
    addWebPage(tmp3, tmp4);

    
}


/*
 * Purpose: Search the BrowserHistory for the specified 
 * web page by ID and return a pointer to that node.
 * @param int id - ID of the web page to look for in LL.
 * @return pointer to node of page, or NULL if not found
 *
 */
WebPage* BrowserHistory::searchPageByID(int id) {
    // TODO
    // start at the head of the linked list and go until it finds the item that's id matches the one we're searching for and return it, or return null if none were found
    WebPage* temp=new WebPage;
    temp=head;

        while(temp!=nullptr)
        {
            if(temp->id==id)
            {
                return temp;
            }
            temp=temp->next;
        }  


    return NULL;
}


/*
 * Purpose: Search the BrowserHistory for the specified 
 * web page by the URL and return a pointer to that node.
 * @param string url - url of the web page to look for in LL.
 * @return pointer to node of page, or NULL if not found
 *
 */
WebPage* BrowserHistory::searchPageByURL(std::string url) {
    // TODO
    // start at the head of the linked list and go until it finds the item that's url matches the one we're searching for and return it, or return null if none were found
    WebPage* temp=head;
        while(temp!=nullptr)
        {
            if(temp->url==url)
            {
                return temp;
            }
            else{
            temp=temp->next;
            }
        } 

    return NULL;
}

/*
 * Purpose: Give an owner to a web page.
 * @param receiver - name of the show that is receiving the rating
 * @param rating - the rating that is being given to a show
 * @return none
 */
void BrowserHistory::addOwner(std::string url, string owner) {
    // TODO
    // start at the head of the linked list and go until it finds the item that's url matches the one we're searching for and add the owner to it
    WebPage* temp=head;
        while(temp!=nullptr)
        {
            if(temp->url==url)
            {
                temp->owner=owner;
                cout << "The owner (" << temp->owner << ") has been added for the ID - " << temp->id << "\n";
                return;
            }
            temp=temp->next;
        } 
        
    
    cout << "Page not found\n";
}

void BrowserHistory::updateViews(string url) {
    // TODO
    // start at the head of the linked list and go until it finds the item that's url matches the one we're searching for and add a view
     WebPage* temp=head;
        while(temp!=nullptr)
        {
            if(temp->url==url)
            {
                temp->views++;
            }
        } 
}
