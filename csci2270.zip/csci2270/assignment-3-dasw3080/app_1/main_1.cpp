#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include "../code_1/browserHistory.hpp"

using namespace std;

void displayMenu();

int main(int argc, char* argv[]) {

    // DO NOT MODIFY THIS.
    if(argc>1) 
    {
        freopen(argv[1],"r",stdin);
    }
    // DO NOT MODIFY ABOVE.

    // TODO

    BrowserHistory brows;

    string option="";
    int choice=0;
    do{
        
        displayMenu();//display the menu
        cin >> choice;//take in user menu option
       
        
        switch (choice)//switch for choice
        {
        case (1)://build history
        {
            brows.buildBrowserHistory();//build the history
            brows.displayHistory();//display the history

            continue;//reprompt
        }
        case(2)://display history
        {
            brows.displayHistory();//display the history
            continue;//reprompt
        }
        case(3)://add web page
        {
            string new_url="";//make string for the new url
            int new_id=0;//make id for the new url
            string previous="";//make string for previous url

            //take in new page url and the id
            cout << "Enter the new web page's url:" << endl;
            cin >> new_url;

            cout << "Enter the new web page's id:" << endl;
            cin >> new_id;

            while(brows.searchPageByID(new_id)!=NULL)//if the id has already been used, reprompt for a new one until a valid one is given
            {
                cout << "This ID already exists. Try again.\n";
                cout << "Enter the new web page's id:" << endl;
                cin >> new_id;
            }
            
            WebPage* new_web= new WebPage;//make a new webpage item and add the new values
            new_web->id=new_id;
            new_web->url=new_url;

            cout << "Enter the previous page's url (or First):" << endl;
            cin >> previous;

                while(brows.searchPageByURL(previous)==NULL&&previous!="First")//reprompt user until a valid url or "first" has been entered
                {
                    cout << "INVALID(previous page url)... Please enter a VALID previous page url!\n";
                    cout << "Enter the previous page's url (or First):" << endl;
                    cin >> previous; 
                }

            if(previous=="First"||previous=="first")// if the user wrote first, pass in the previous object as a nullptr
            {
                brows.addWebPage(nullptr, new_web);
            }
            else//if the users choice was a url
            {
                brows.addWebPage(brows.searchPageByURL(previous), new_web);
            }
            continue;//reprompt
        }
        case(4)://add owner
        {
            //create new variables to take from user
            string owner="";
            string url="";

            cout << "Enter url of the web page to add the owner:" << endl;
            cin >> url;

            while(brows.searchPageByURL(url)==NULL) //while the page isnt found, remprompt the user til they enter a valid url
            {
                cout << "Page not found. Try again." << endl;
                cout << "Enter url of the web page to add the owner: " << endl;
                cin >> url;
            }

            cout << "Enter the owner:";
            cin.ignore();// use get line to make sure if the owners name has two words it doesnt only take the first one
            getline(cin,owner);

            brows.addOwner(url, owner);//add the owner to the url

            continue;//reprompt
        }
        case(5)://view
        {
            //ask user to input url
            string url;
            cout << "Enter url of the web page to check the view count: \n"; 
            cin >> url;

            WebPage* temp= brows.searchPageByURL(url);
            while(temp==NULL)//while the url isnt found, reprompt until a correct one is
            {
                cout << "Page not found. Try again.\n";
                cout << "Enter url of the web page to check the view count: \n";
                cin >> url;
                temp= brows.searchPageByURL(url);
            }

            cout << "View count for URL - " << url << " is " << temp->views << "\n";//output the view count

            continue;//reprompt
        }

        }


    }while (choice!=6);//when the user chooses 6, quit the loop
    cout << "Quitting...Goodbye!\n";
    
    return 0;
}




/************************************************
           Definitions for main_1.cpp
************************************************/
void displayMenu()
{
    // COMPLETE: You DO NOT need to edit this
    cout << "Select a numerical option:" << endl;
    cout << "+=====Main Menu=========+" << endl;
    cout << " 1. Build history " << endl;
    cout << " 2. Display history " << endl;
    cout << " 3. Add web page " << endl;
    cout << " 4. Add owner" << endl;
    cout << " 5. View count for a web page" << endl;
    cout << " 6. Quit " << endl;
    cout << "+-----------------------+" << endl;
    cout << "#> ";
}
