#include <iostream>
#using namespace std;


Node *temp1;
Node *temp2;

while ((temp1 !=nulltpr) && (temp2 != nullptr))
{
    temp1=temp1->next;
    temp2=temp2->next;

    if (temp2 != nullptr)break;
    {
        temp2=temp2->next;
    }
    if (temp1=temp2)
    {
        return temp1;
    }
}