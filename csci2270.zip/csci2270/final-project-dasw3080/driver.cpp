#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "MovieHashTable.hpp"
#include "DirectorSkipList.hpp"

using namespace std;

//driver.cpp has the menu, opens file, creates objects for hash table and skip lists

// Function prototypes
MovieNode* parseMovieLine(string line);
void readMovieCSV(string filename,  MovieHashTable &movieTable, DirectorSkipList &directorList);
void display_menu();


// Main function
int main(int argc, char* argv[]) {
    // TODO
    srand(time(0));//start time in order to get random numbers for skip list
    if (argc !=4)//if the command line input isn't correct
    {
        cout << "Invalid number of arguments." << endl;
        cout << "Usage: ./<program_name> <csv file> <hashTable size> <skipList size>" << endl;
    }
    else{
    string filename="";
    filename=argv[1];
    int hashSize= stoi(argv[2]);
    int skipSize= stoi(argv[3]);

    DirectorSkipList directorList = DirectorSkipList(skipSize,10);//create new skiplist
    MovieHashTable movieTable= MovieHashTable(hashSize);//create new hash table
    

    readMovieCSV(filename, movieTable, directorList);//run file through readmoviecsv


    int choice=0;

    do 
    {
        cout << "Number of collisions: " << movieTable.getCollisions() << endl;//display number of collisions from the table
        display_menu();//display menu and take in user choice
        cin >> choice;
        
        while(choice<1 || choice>5)//if the choice isnt between 1 and 5 the user will be reprompted
        {
            cout << "Number of collisions: " << movieTable.getCollisions() << endl;
            display_menu();
            cin >> choice;
        }

        switch(choice)//switch case for each option
        {
            case(1)://find the director
            {
              string movie="";
               cout << "Enter movie name: " << endl;
               cin.ignore();
               getline(cin, movie);//take in the whole movie name
                cout << " " << endl;
                MovieNode* director = movieTable.search(movie);//search the hash table for the movie

                if (director==nullptr)//if the movie wasn't found, tell the user
                {
                    cout << "The movie, " << movie << ", was not found." << endl;
        
                }
                else// if it was, print out the director of the movie
                {
                    cout<< "The director of " << movie << " is " << director->director << endl;
                }
                break;
            }
            case(2)://number of movies by director
            {
                string director="";
                cout << "Enter a director name:" << endl;
                cin.ignore();
                getline(cin, director);//take in the whole director name
                cout << " " << endl;
                DirectorSLNode* blah = directorList.search(director);//search skiplist for director
                if (blah==nullptr)//if the director wasn't found, tell the user
                {
                    cout << director << " not found." << endl;
                }
                else//else, get the number of movies in the vector of movies and tell the user how many
                {
                    int size= blah->movies.size();
                    cout << "The number of movies directed by " << director << " is : " << size << endl; 
                } 
                break;
            }
            case(3)://descrption of movie
            {
                string movie = "";
                cout << "Enter a movie name:" << endl;
                cin.ignore();
                getline(cin, movie);//take in the whole movie name
                cout << " " << endl;
                MovieNode* description = movieTable.search(movie);//search the hash table for the movie

                if (description==nullptr)//if the movie was not found tell the usser
                {
                    cout << "The movie, " << movie << ", was not found." << endl;
                }
                else//tell the user the description of the film
                {
                    cout << movie << ", released in " << description->year << ", is a " << description->genre << " film. " << description->actors << " tell the story about " << description->description <<endl;
                }
                break;
            }
            case(4)://movies by director
            {
                string director="";
                cout << "Enter a director name:" << endl;
                cin.ignore();
               getline(cin, director);//take in the whole director name

                DirectorSLNode* blah = directorList.search(director);//search the skip list for the director
                cout << " " << endl;
                if (blah==nullptr)//if the director wasn't found, tell the user
                {
                    cout << director << " not found." << endl;
                }
                else
                {
                    for (int i=0; i<int(blah->movies.size()); i++)//else go through the movie vector and display all of the movies by the director
                    {
                        cout << i+1 << ": " << blah->movies[i]->title << endl;
                    } 
                } 
                break;
            }
        }
    }while(choice!=5);//exit the loop user chooses to quit
    }

    return 0;
}

// Function to parse a CSV line into a MovieNode object
MovieNode* parseMovieLine(string line) {
    stringstream ss(line);
    vector<string> fields;
    string field;

    // Loop through the characters in the line
    bool in_quotes = false;
    for (size_t i = 0; i < line.length(); ++i) {
        char c = line[i];
        if (c == '\"') {
            in_quotes = !in_quotes;
        } else if (c == ',' && !in_quotes) {
            // add field to vector and reset for next field
            fields.push_back(field);
            field.clear();
        } else {
            field += c;
            // handle double quotes inside a quoted field
            if (in_quotes && c == '\"' && i < line.length() - 1 && line[i+1] == '\"') {
                field += '\"'; // add the second double quote and skip it
                ++i;
            }
        }
    }
    fields.push_back(field);

    if (fields.size() != 12) {
        cerr << "Error: Invalid movie line format" << line << endl;
        return nullptr;
    }

    int rank = stoi(fields[0]);
    string title = fields[1];
    string genre = fields[2];
    string description = fields[3];
    string director = fields[4];
    string actors = fields[5];
    int year = stoi(fields[6]);
    int runtime = stoi(fields[7]);
    float rating = stof(fields[8]);
    int votes = stoi(fields[9]);
    float revenue = stof(fields[10]);
    int metascore = stoi(fields[11]);

    // Create a new MovieNode object with the parsed fields
    MovieNode* movie = new MovieNode(rank, title, genre, description, director, actors, year, runtime, rating, votes, revenue, metascore);
    return movie;
}

/*
readMovieCSV(string filename,  MovieHashTable &movieTable, DirectorSkipList &directorList)- read file and then insert it into hash table and skip list 
Parameters-string filename,  MovieHashTable &movieTable, DirectorSkipList &directorList
Returns-nothing
*/
// Function to read a CSV file into a vector of MovieNode objects
void readMovieCSV(string filename,  MovieHashTable &movieTable, DirectorSkipList &directorList) {
    // TODO
    ifstream file;//create a new ifstream object
    file.open(filename);//open the file 
    string line = "";
    int count=0;//start a count so that the file doesn't read the first line
    if (file.is_open()){//if the file is open it can start
    while(getline(file, line))//gets each line of the file
    {
        if (count>0)//doesn't read the first line
        {
            MovieNode* movie = parseMovieLine(line);//put the line through parse line and make a movie node from it
            movieTable.insert(movie->title, movie);//add the movie to the table
            directorList.insert(movie->director, movie);//and the director skip list
        }

        count++;//increment count, unimportant after first iteration
    }
    }
   
    file.close();//close the file
}

/*
display_menu()- display menu to user when called
Parameters-none
Returns- none
*/
// Function to display the menu options
void display_menu() {
    // TODO

   cout << "Please select an option: " << endl;
   cout <<  "1. Find the director of a movie" << endl;
   cout << "2. Find the number of movies by a director" << endl;
   cout <<  "3. Find the description of a movie" << endl;
   cout << "4. List movies by a director" << endl;
   cout << "5. Quit" << endl;
   cout << " " << endl;
   cout << "Enter an option: " << endl;


}
