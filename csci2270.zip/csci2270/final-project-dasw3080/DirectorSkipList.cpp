#include<iostream>
#include <vector>
#include "DirectorSkipList.hpp"
using namespace std;


//DirectorSkipList.cpp implements constructors, a destructor, and insert and search features for the skip list


// Constructor for DirectorSkipList with default capacity and levels
/*
DirectorSkipList()- sets default levels and capacity, constructs a head for the skip list and the vector of its next pointers
Parameters- none
Returns- none
*/
DirectorSkipList::DirectorSkipList() {
    // TODO
    capacity=DEFAULT_CAPACITY;//set capacity and levels
    levels=DEFAULT_LEVELS;
    head = new DirectorSLNode();//make a new head
    head->next = vector<DirectorSLNode*>(levels, nullptr);//make a vector for heads next with the number of levels given
}

// Constructor for DirectorSkipList with given capacity and levels
/*
DirectorSkipList(int _cap, int _levels)- sets given levels and capacity, constructs a head for the skip list and the vector of its next pointers
Parameters- none
Returns- none
*/
DirectorSkipList::DirectorSkipList(int _cap, int _levels) {
    // TODO
    capacity=_cap;//set capacity and levels
    levels=_levels;
    head = new DirectorSLNode();//make a new head
    head->next = vector<DirectorSLNode*>(levels, nullptr);//make a vector for heads next with the number of levels given
}

// Destructor for DirectorSkipList that deletes all nodes in the skip list (but not the MovieNodes, which are shared with other data structures)
/*
~DirectorSkipList()-- deletes all nodes using linked list at position zero
Parameters- none
Returns-none
*/
DirectorSkipList::~DirectorSkipList() {
    // TODO
    DirectorSLNode * curr=head;//find the head
    DirectorSLNode* prev;//set prev
    while(curr!=nullptr)
    {
        prev=curr;//set prev to curr to hold on to it
        curr=curr->next[0];//increment curr forward
        delete prev;//delete prev to release it
    }
}

/*
insert(string director, MovieNode* _movie)- adds a movie to a director in the skip list
Parameters- string director, MovieNode* _movie 
Returns- none 
*/
// Inserts a movie node into the skip list with the specified director
void DirectorSkipList::insert(string director, MovieNode* _movie) {
    // TODO

    if(search(director)!=nullptr)//if the director already exists, add just the movie to the movie vector
    {
        search(director)->addMovie(_movie);
    }
    else//we have to add a director to the skip list 
    {
        DirectorSLNode* ptr = head;//find the head
        DirectorSLNode* prev[levels];//create an array of the last director at each level of the skip list

        for (int i=levels-1; i>=0;i--)//start from the top of the list and go to the bottom
        {
            while(ptr->next[i]!=nullptr && ptr->next[i]->director < director)//if the next exists and it is to the left of where the director needs to be placed
            {
                ptr=ptr->next[i];//move to the next node in that level
            }

            prev[i]=ptr;//after we reach the end vs ^^ conditions, add it to the array
        }


        int n_levels=1;//start number of levels at at least one

        while(n_levels< levels && rand() % 2 == 0 )// flip a coin until it lands on tails to determine random number of levels
        {
            n_levels++;
        }
     
       DirectorSLNode* director1 = new DirectorSLNode(director, n_levels);//create a new director node given the director and the levels determined ^^
       director1->addMovie(_movie);// add the movie to the movie vector

        for (int i=0; i< n_levels; i++)//go through prev array created to create connections
        {
            director1->next[i]=prev[i] ->next[i];//directors next takes prevs next
            prev[i]->next[i]=director1;//prevs next is now director
        }
    }
}
/*
search(string director)- searches the skip list for the director given
Parameters- string director
Returns- DirectorSLNode* found 
*/
// Searches for a node in the skip list with the specified director
DirectorSLNode *DirectorSkipList::search(string director) {
    // TODO
        DirectorSLNode* ptr = head; //find head

        for (int i=levels-1; i>=0;i--)// traverse from top level to the bottom to the node before what should be the given director
        {
            while(ptr->next[i]!=nullptr && ptr->next[i]->director < director)
            {
                ptr=ptr->next[i];
            }
        }

        ptr=ptr->next[0];//the next ptr should be director it's searching for  

        if (ptr!=nullptr && ptr->director==director)//if it matches then return it
        {
            return ptr;
        }

        return nullptr;//if it doesn't, return nullptr
}

/*
prettyPrint()- prints the skip list nicely
Parameters- none
Returns- none
*/
// Pretty-prints the skip list
void DirectorSkipList::prettyPrint() {
    // TODO
    for (int i=levels-1; i>=0; i++)//start top to bottom levels
    {
        cout <<"Level " << levels+1 << ": ";

        DirectorSLNode* ptr= head;

        cout << ptr->director << " -> ";

        while(ptr->next[i]!=nullptr)//go through vectors of next to get levels in order
        {
            cout << ptr->next[i]->director << " -> ";
            ptr=ptr->next[i];     
        }
        cout << "NULL" << endl;
    }
}
