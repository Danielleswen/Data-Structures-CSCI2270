1. Which hash collision resolution method did you use and why?
I used chaining because I really like linked lists and I think that it's easier to push back the node at the location where there is a collision, rather than increment positions whether linearly or quadratically, until there is an open space. I implemented it by having the new movie node being placed at the head position in the hash table and having it point to all the previous nodes that stemmed from that position. 

2. Explain your hash function
My hash function manipulates my identikey dasw3080 by iterating through the letters in the title and getting their ascii value and adding the value of 'd' and 'a' and multiplying them by 30 and 80. I then divide it by the value of 's' plus the value of 'w'. I return that number modded by the table size. 

3. Did you implement skip list to search for director specific information? 
I did because I thought it'd be a good challenge for me to figure out

4. Explain any additional features you have implemented
I didn''t implement any other features



<img src="https://www.colorado.edu/cs/profiles/express/themes/ucb/images/cu-boulder-logo-text-black.svg" alt="CU Boulder Logo" width="500">

# CSCI 2270: Data Structures <br/> IMDB Movies Database Project

This project is a simple implementation of a movie database using C++ and two data structures: a hash table and a skip list. Please go through *CSCI2270_Spring23_Project.pdf* for the detailed instructions.

## Requirements

1. C++ compiler 
2. A CSV file containing movie data (e.g. IMDB-Movie-Data.csv)

## Installation

1. Clone the repository
2. Compile the code : `g++ -std=c++11 driver.cpp MovieHashTable.cpp DirectorSkipList.cpp -o movie-db`
3. Run the program: `./movie-db IMDB-Movie-Data.csv 2000 2000`
4. Follow the on-screen menu to perform different operations on the movie database.

## Data Structures

This project uses two data structures to store and retrieve movie data: a hash table and a skip list.

### Hash Table
The hash table is used to map movie titles to `MovieNode` objects. 
The hash function used is a custom function that takes the sum of the ASCII codes of all characters in the title string and calculates the modulo of the sum by the hash table size. Students must use their identikey to come up with a creative hash function that minimizes collisions
for the given IMDB-Movie database to ensure efficient insertion and retrieval of movie nodes.

### Skip List
The skip list is used to map director names to `DirectorSLNode` objects, which contain a vector of `MovieNode` pointers. The skip list is a probabilistic data structure that allows for efficient search, insertion, and deletion of elements. It is implemented using a linked list with multiple levels, where each level has fewer nodes than the level below it. The skip list used in this project has a fixed number of levels (10) and a fixed capacity (2000).

