#include<iostream>
#include <vector>
#include "MovieHashTable.hpp"
using namespace std;

//MovieHashTable.cpp implements constructors, a destructor, and insert and search features for the skip list

/*
MovieHashTable()- sets default capacity and collisions to 0 and creates a new hash table of MovieNodes
Parameters- none
Returns- none
*/
// Constructor for MovieHashTable with default size
MovieHashTable::MovieHashTable() {
    // TODO
    table_size=DEFAULT_HTABLE_CAPACITY;//set capacity 
    n_collisions=0;//set collisions to 0

    table = new MovieNode* [table_size];//create a new table of the table size
    for(int i=0;i<table_size;i++)//set all positions to nullptr
    {
        table[i] = nullptr;
    }
}

/*
MovieHashTable(int s)- sets given capacity and collisions to 0 and creates a new hash table of MovieNodes
Parameters- none
Returns- none
*/
// Constructor for MovieHashTable with given size
MovieHashTable::MovieHashTable(int s) {
    // TODO
    table_size=s;//set capacity
    n_collisions=0;//set collisions to 0

    table = new MovieNode*[table_size];//create a new array of the table size
    for(int i=0;i<table_size;i++)//set all positions to nullptr
    {
        table[i] = nullptr;
    }
}

/*
~MovieHashTable()- goes through the table and each node at the position and deletes them
Parameters- none
Returns-none
*/
// Destructor for MovieHashTable that deletes all nodes in the hash table
MovieHashTable::~MovieHashTable() {
    // TODO
    MovieNode* prev;//create prev node
    MovieNode* curr;//create curr

    for (int i=0; i< table_size; i++)//go through table to delete
    {
        curr=table[i];//get node at table positions
        prev=nullptr;

        while(curr!=nullptr)//go through linked list
        {
            prev=curr;//set the prev
            curr=curr->next;//move the current node to next
            delete prev;//delete the prev node
        }
    }

    delete[] table;//delete the table
}


/*
hash(string title)-generates a random key based off of identikey dasw3080 and ascii values of the title of the movie
Parameter- string title
Return- int hashkey
*/
// Hash function for MovieHashTable that returns an index in the hash table for a given movie title.
// Students must use their identikey to come up with a creative hash function that minimizes collisions
// for the given IMDB-Movie database to ensure efficient insertion and retrieval of movie nodes.
int MovieHashTable::hash(string title) {
    // TODO
    int num1=0;//start number at 0

       for(int i = 0; i < int(title.size());i++){//increment through ascii values of title string and modulate
       num1 += (int(title[i]) + int('d') + int('a'))* 30 * 80;// use dasw3080
       num1 = num1/(int('s') + int('w'));// use dasw3080 
   }


    return num1 % table_size;//return mod key

}

/*
insert(string title, MovieNode* movie)- insert movie node into hash table and use chaining to fix collisions
Parameters-string title, MovieNode* movie
Returns- nothing
*/
// Inserts a movie node into the hash table with the specified title
void MovieHashTable::insert(string title, MovieNode* movie) {
    // TODO

    MovieNode* head=table[hash(title)];//find the head of the linked list at the key position
    if (head!=nullptr)//if a collision is found
    {
        setCollisions();//add one to collisions
    }
    movie->next=head;//insert the movie at the head of the list, make head movie's next
    table[hash(title)]=movie;//place movie at head

}

/*
search(string title)- search the hash table for the title and return the node if found
Parameters-string title
Returns-MovieNode* movie
*/
// Searches for a node in the hash table with the specified title
MovieNode* MovieHashTable::search(string title) {
    // TODO
   int key = hash(title);//get the key for the position in the hash table

    MovieNode* curr=table[key];//get the node at the position in the hash 
    while(curr!= nullptr)//go through linked list
    {
        if (curr->title==title)//if the title matches return the node
        {
            return curr;
        }
        curr=curr->next;//move to the next node
    }

    return nullptr;
}

/*
getCollisions()- return the number of collisions
Parameters-none
Returns-int number of collisions
*/
// Returns the number of collisions that have occurred during insertion into the hash table
int MovieHashTable::getCollisions() {
    // TODO
    return n_collisions;
}

/*
setCollisions()- increment the number of collisions by one
Parameters-none
Returns-none
*/
// Increments the number of collisions that have occurred during insertion into the hash table
void MovieHashTable::setCollisions() {
    // TODO
    n_collisions++;
}
